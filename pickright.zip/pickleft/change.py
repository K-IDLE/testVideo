import os

len = os.listdir('../pickright')

print(len)
cnt = 0
for i in len[1:]:
    os.rename("%s"%(i), "P03_S00_A36_F%04d.jpg"%(cnt))
    cnt = cnt + 1
